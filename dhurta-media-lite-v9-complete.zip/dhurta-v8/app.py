import json, os, re, shutil, subprocess, sys, threading, time, uuid, webbrowser, urllib.parse
from pathlib import Path
from flask import Flask, jsonify, render_template, request, send_from_directory

BASE = Path(__file__).resolve().parent
APPDATA = Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'.local'/'share')) / 'Dhurta Media'
WORK_ROOT = APPDATA / 'jobs'
LOG_ROOT = APPDATA / 'logs'
CONFIG = APPDATA / 'config.json'
for p in (WORK_ROOT, LOG_ROOT): p.mkdir(parents=True, exist_ok=True)
app = Flask(__name__)
LOCK = threading.RLock(); JOBS = {}

DEFAULT = {
    'download_folder_name':'Dhurta Media', 'browser':'none', 'use_cookies':False,
    'quality':'best','container':'mp4','audio_format':'mp3','audio_quality':'192K',
    'retries':8,'fragment_retries':15,'concurrent_fragments':2,'sleep_interval':0,'max_sleep_interval':0,'rate_limit':'',
    'embed_metadata':True,'embed_thumbnail':False,'embed_subtitles':False,'subtitle_lang':'en.*',
    'filename_template':'%(title)s [%(id)s].%(ext)s','auto_cleanup':True
}
BROWSERS=['firefox','chrome','edge','brave','opera','vivaldi','chromium']
MEDIA_EXT={'.mp4','.mkv','.webm','.mov','.m4v','.mp3','.m4a','.opus','.wav','.flac','.aac','.ogg'}

def cfg():
    try: d=json.loads(CONFIG.read_text(encoding='utf-8')) if CONFIG.exists() else {}
    except Exception: d={}
    x=DEFAULT.copy(); x.update({k:v for k,v in d.items() if k in DEFAULT}); return x

def save_cfg(d):
    x=DEFAULT.copy(); x.update({k:v for k,v in (d or {}).items() if k in DEFAULT}); CONFIG.parent.mkdir(parents=True,exist_ok=True); CONFIG.write_text(json.dumps(x,indent=2),encoding='utf-8'); return x

def downloads_dir():
    name=str(cfg().get('download_folder_name') or 'Dhurta Media').strip() or 'Dhurta Media'
    if os.name=='nt':
        try:
            import ctypes
            from ctypes import wintypes
            class GUID(ctypes.Structure): _fields_=[('Data1',wintypes.DWORD),('Data2',wintypes.WORD),('Data3',wintypes.WORD),('Data4',wintypes.BYTE*8)]
            g=GUID(0x374DE290,0x123F,0x4565,(ctypes.c_ubyte*8)(0x91,0x64,0x39,0xC4,0x92,0x5E,0x46,0x7B)); p=ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(g),0,None,ctypes.byref(p))==0 and p.value:
                d=Path(p.value)/name; d.mkdir(parents=True,exist_ok=True); return d
        except Exception: pass
    d=Path.home()/'Downloads'/name; d.mkdir(parents=True,exist_ok=True); return d

def candidate_ffmpeg():
    vals=[]
    env=os.environ.get('DHURTA_FFMPEG');
    if env: vals += [Path(env),Path(env)/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg')]
    vals += [BASE/'bin'/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg'), BASE/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg')]
    try:
        import imageio_ffmpeg; vals.append(Path(imageio_ffmpeg.get_ffmpeg_exe()))
    except Exception: pass
    w=shutil.which('ffmpeg')
    if w: vals.append(Path(w))
    seen=set()
    for p in vals:
        try:
            p=p.resolve()
            if p in seen or not p.exists(): continue
            seen.add(p)
            r=subprocess.run([str(p),'-version'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=8)
            if r.returncode==0: return str(p)
        except Exception: continue
    return None

def ffprobe_for(ff):
    if not ff:return None
    p=Path(ff); q=p.with_name('ffprobe.exe' if os.name=='nt' else 'ffprobe')
    if q.exists():
        try:
            if subprocess.run([str(q),'-version'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=8).returncode==0:return str(q)
        except Exception: pass
    w=shutil.which('ffprobe')
    if w:return w
    return None

def engine_status():
    ff=candidate_ffmpeg(); fp=ffprobe_for(ff)
    return {'available':bool(ff),'ffmpeg':ff,'ffprobe':fp,'ready':bool(ff),'message':('Ready' if ff else 'FFmpeg unavailable or could not start')}

def ytdlp_exe():
    p=BASE/'.venv'/('Scripts/yt-dlp.exe' if os.name=='nt' else 'bin/yt-dlp')
    return str(p) if p.exists() else 'yt-dlp'

def browser_from_request():
    b=(request.args.get('browser') or request.headers.get('X-Dhurta-Browser') or '').lower()
    if b in BROWSERS or b=='none': return b
    ua=request.headers.get('User-Agent','').lower()
    if 'firefox' in ua:return'firefox'
    if 'edg/' in ua:return'edge'
    if 'opr/' in ua:return'opera'
    if 'vivaldi' in ua:return'vivaldi'
    if 'brave' in ua:return'brave'
    if 'chrome' in ua:return'chrome'
    return 'none'

def cookie_args(c):
    if not c.get('use_cookies') or c.get('browser') in ('none','auto',''): return []
    return ['--cookies-from-browser',c['browser']]

def common(c):
    a=['--no-playlist','--newline','--continue','--retries',str(max(1,int(c.get('retries',8)))), '--fragment-retries',str(max(1,int(c.get('fragment_retries',15)))), '--concurrent-fragments',str(max(1,int(c.get('concurrent_fragments',2)))), '--no-overwrites','--no-cache-dir']
    a += cookie_args(c)
    if c.get('rate_limit'):a += ['--limit-rate',str(c['rate_limit'])]
    si=int(c.get('sleep_interval') or 0); msi=int(c.get('max_sleep_interval') or 0)
    if si:a += ['--sleep-interval',str(si)]
    if msi:a += ['--max-sleep-interval',str(msi)]
    ff=candidate_ffmpeg()
    if ff:a += ['--ffmpeg-location',ff]
    return a

def classify(s):
    s=(s or '').lower()
    if 'database is locked' in s or ('could not copy' in s and 'cookie' in s):return'browser_locked'
    if 'ffmpeg' in s and ('not found' in s or 'not installed' in s or 'could not' in s or 'unable to' in s or 'no such file' in s):return'ffmpeg'
    if 'requested format is not available' in s or 'requested format not available' in s or 'format is not available' in s or 'no video formats found' in s:return'format_unavailable'
    if 'sign in to confirm' in s or 'not a bot' in s or 'captcha' in s:return'youtube_verification'
    if 'proof of origin' in s or 'po token' in s:return'po_token'
    if 'private video' in s or 'login required' in s:return'login_required'
    if 'age-restricted' in s or 'confirm your age' in s:return'age_restricted'
    if 'unsupported url' in s:return'unsupported_url'
    if 'permission denied' in s or 'access is denied' in s:return'permission'
    if 'disk full' in s or 'no space left' in s:return'disk_full'
    if 'timed out' in s or 'timeout' in s:return'network_timeout'
    return'generic'

def error_help(k):
    return {
      'ffmpeg':'The media engine is unavailable. Click System Check first, then use Repair Media Engine. If Windows Security quarantined ffmpeg, restore/allow the local Dhurta engine and retry.',
      'format_unavailable':'The selected stream was unavailable or changed. Dhurta automatically tries compatible fallbacks; if all fail, re-analyze the URL and select a newly generated quality button.',
      'browser_locked':'Browser cookies are locked. Turn off Use browser session and retry. Cookie-free mode is recommended and does not require closing the browser.',
      'youtube_verification':'YouTube requested normal verification. Open the video normally in YouTube, complete any verification it presents, then re-analyze. Dhurta does not bypass verification.',
      'po_token':'YouTube requires an additional token for this request. Retry later or use another normally accessible video; Dhurta does not bypass access controls.',
      'login_required':'This video requires account access. Cookie-free mode cannot provide that access.',
      'age_restricted':'This video requires age/account access that is not available in cookie-free mode.',
      'permission':'Windows denied access to the destination folder. Choose a writable Dhurta folder or check folder permissions.',
      'disk_full':'There is not enough free storage for this download. Free space and retry.',
      'network_timeout':'The connection timed out. Check the network, reduce concurrent fragments, then retry.',
      'unsupported_url':'This build accepts supported YouTube URLs only.',
      'generic':'Open Technical details below. The first ERROR line normally identifies the exact failing stage. Run System Check and retry after following the suggested step.'
    }.get(k,'Check Technical details and retry.')

def normalize_youtube_url(u):
    u=(u or '').strip()
    try:
        x=urllib.parse.urlsplit(u)
        host=(x.hostname or '').lower()
        if host=='youtu.be':
            vid=x.path.strip('/').split('/')[0]
            if not vid: return None
            return 'https://www.youtube.com/watch?v='+urllib.parse.quote(vid)
        if host not in {'youtube.com','www.youtube.com','m.youtube.com','music.youtube.com'}:
            return None
        if not x.path or x.path=='/': return None
        # Keep supported YouTube paths. yt-dlp handles watch, shorts, live, embed, etc.
        return urllib.parse.urlunsplit(('https',host,x.path,x.query,''))
    except Exception:
        return None

def valid(u):
    return normalize_youtube_url(u) is not None

def run(args,timeout=None):
    return subprocess.run(args,cwd=BASE,text=True,capture_output=True,timeout=timeout,encoding='utf-8',errors='replace')

def probe(url,c):
    url=normalize_youtube_url(url)
    attempts=[]
    if c.get('use_cookies') and c.get('browser') not in ('none','auto',''):
        attempts.append(c['browser'])
    attempts.append('none'); last=''
    for b in dict.fromkeys(attempts):
        cc=c.copy(); cc['browser']=b; cc['use_cookies']=(b!='none')
        p=run([ytdlp_exe()]+common(cc)+['--dump-single-json','--skip-download',url],timeout=180)
        out=(p.stdout or '').strip()
        if p.returncode==0 and out:
            for line in reversed(out.splitlines()):
                if line.lstrip().startswith('{'):
                    try:return json.loads(line),None,b
                    except Exception: break
        last=(p.stderr or p.stdout or '')[-16000:]
        if classify(last)=='browser_locked': continue
    return None,last,None

def analyze_formats(info):
    heights={}
    for f in info.get('formats') or []:
        try:h=int(f.get('height') or 0)
        except Exception: continue
        vc=f.get('vcodec'); ac=f.get('acodec')
        if h<1 or not vc or vc=='none': continue
        item={'format_id':f.get('format_id'),'height':h,'width':f.get('width'),'fps':f.get('fps'),
              'ext':f.get('ext'),'video_codec':vc,'audio_codec':None if not ac or ac=='none' else ac,
              'has_audio':bool(ac and ac!='none'),'filesize':f.get('filesize') or f.get('filesize_approx'),
              'tbr':f.get('tbr'),'mp4_compatible':bool(f.get('ext')=='mp4' and str(vc).startswith('avc1')),
              'progressive':bool(ac and ac!='none')}
        heights.setdefault(h,[]).append(item)
    qs=[]
    for h in sorted(heights,reverse=True):
        arr=heights[h]
        best=max(arr,key=lambda x:(1 if x['mp4_compatible'] else 0,1 if x['has_audio'] else 0,x.get('filesize') or 0,x.get('tbr') or 0))
        qs.append({'height':h,'width':best.get('width'),'fps':best.get('fps'),'ext':best.get('ext'),
                   'video_codec':best.get('video_codec'),'has_audio':best.get('has_audio'),
                   'mp4_compatible':best.get('mp4_compatible'),'progressive':best.get('progressive'),
                   'format_ids':[x['format_id'] for x in arr]})
    return qs

def format_ladder(q,container):
    """Ordered selectors. Each attempt is deliberately valid on its own.
    This avoids the old bug where an exact-height MP4 selector rejected a perfectly
    usable WebM/progressive format and the job died with 'requested format unavailable'.
    """
    try: q=int(q) if q not in (None,'','best') else None
    except Exception: q=None
    h=f'[height={q}]' if q else ''
    le=f'[height<={q}]' if q else ''
    if container=='mp4':
        out=[]
        if q: out.append((f'bv*{h}[ext=mp4][vcodec^=avc1]+ba[ext=m4a]/b{h}[ext=mp4]','mp4','selected MP4'))
        out.append((f'bv*[ext=mp4][vcodec^=avc1]+ba[ext=m4a]/b[ext=mp4]','mp4','best MP4 fallback'))
        if q: out.append((f'bv*{h}+ba/b{h}','mkv','selected resolution compatibility fallback'))
        out.append((f'bv*{le}+ba/b{le}' if q else 'bv*+ba/best','mkv','best compatible fallback'))
        out.append(('b[ext=mp4]/b','mp4','single-file fallback'))
        return out
    if container=='webm':
        out=[]
        if q: out.append((f'bv*{h}[ext=webm]+ba[ext=webm]/b{h}[ext=webm]','webm','selected WebM'))
        out.append(('bv*[ext=webm]+ba[ext=webm]/b[ext=webm]','webm','best WebM fallback'))
        if q: out.append((f'bv*{h}+ba/b{h}','mkv','selected resolution fallback'))
        out.append((f'bv*{le}+ba/b{le}' if q else 'bv*+ba/best','mkv','best compatible fallback'))
        return out
    # MKV is the least restrictive container.
    return ([(f'bv*{h}+ba/b{h}','mkv','selected resolution')] if q else []) + [(f'bv*{le}+ba/b{le}' if q else 'bv*+ba/best','mkv','best compatible fallback')]

def safe_template(t):
    t=(t or DEFAULT['filename_template']).strip().replace('..','_').replace('/','_').replace('\\','_')
    return t[:220] or DEFAULT['filename_template']

def cleanup_job(work):shutil.rmtree(work,ignore_errors=True)

def log_line(j,line):
    if line:j.setdefault('logs',[]).append(line[-1600:]);j['logs']=j['logs'][-100:]

def start_job(jid,url,c):
    j=JOBS[jid]; work=WORK_ROOT/jid; work.mkdir(parents=True,exist_ok=True); dl=downloads_dir(); ff=engine_status()
    j.update(download_dir=str(dl),engine=ff,stage='preparing',progress=0.0,progress_source='waiting')
    if j['mode']=='audio' and not ff['ready']:
        j.update(status='error',error_kind='ffmpeg',message='Audio conversion needs the media engine',error=ff['message'],help=error_help('ffmpeg')); return
    template=safe_template(c.get('filename_template'))
    q=j.get('quality','best'); container=j.get('container','mp4')
    attempts=[{'selector':x[0],'merge':x[1],'label':x[2]} for x in ([(f'ba/b','mp3','audio')] if j['mode']=='audio' else format_ladder(q,container))]
    last_error=''; final=None
    j.update(status='starting',message='Preparing download…',error=None,error_kind=None,last_error=None,attempt=0,attempts=len(attempts),fallback_used=False)
    for idx,a in enumerate(attempts,1):
        if j.get('pause_requested'):
            j.update(status='paused',message='Paused. Resume to continue.',pause_requested=False); return
        j['attempt']=idx; j['stage']='downloading'; j['progress']=0.0; j['progress_source']='yt-dlp'; j['message']=f'Downloading — strategy {idx}/{len(attempts)}'
        attempt_dir=work/f'attempt-{idx}'; attempt_dir.mkdir(parents=True,exist_ok=True)
        args=[ytdlp_exe()]+common(c)+['--paths',f'home:{dl}',f'temp:{attempt_dir}','-o',template,
             '--print','after_move:__FINAL__ %(filepath)s',
             '--progress-template','download:__PROGRESS__|%(progress.status)s|%(progress._percent_str)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.speed)s|%(progress.eta)s',
             '--progress-template','postprocess:__POST__|%(progress.status)s|%(progress._percent_str)s']
        if j['mode']=='video':
            args += ['-f',a['selector']]
            if a['merge'] in ('mp4','mkv','webm') and '+' in a['selector']:
                args += ['--merge-output-format',a['merge']]
        else:
            args += ['-f','ba/b','-x','--audio-format',c.get('audio_format','mp3'),'--audio-quality',c.get('audio_quality','192K')]
        if c.get('embed_thumbnail'): args += ['--embed-thumbnail']
        if c.get('embed_subtitles'): args += ['--embed-subs','--sub-langs',c.get('subtitle_lang','en.*')]
        if c.get('embed_metadata'): args += ['--embed-metadata']
        args += [normalize_youtube_url(url) or url]
        log_file=LOG_ROOT/f'{jid}.log'; rc=1; p=None; final=None
        try:
            p=subprocess.Popen(args,cwd=BASE,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf-8',errors='replace',bufsize=1)
            j['pid']=p.pid
            with log_file.open('a',encoding='utf-8') as lf:
                for raw in p.stdout:
                    line=raw.rstrip(); lf.write(line+'\n'); lf.flush(); log_line(j,line)
                    if line.startswith('__FINAL__ '): final=Path(line[len('__FINAL__ '):].strip())
                    if line.startswith('__PROGRESS__|'):
                        parts=line.split('|',6)
                        if len(parts)>=7:
                            _,status,pct,done,total,speed,eta=parts
                            try:
                                val=float(pct.replace('%','').strip()) if pct.strip() not in ('N/A','NA','Unknown','') else 0.0
                                # Download occupies 0..95%; post-processing gets 95..99%.
                                j['progress']=max(0.0,min(95.0,val*0.95))
                            except Exception: pass
                            j.update(downloaded=done,total=total,speed=speed,eta=eta,status='downloading',stage='downloading',progress_source='yt-dlp',message='Downloading…')
                    elif line.startswith('__POST__|'):
                        j.update(status='processing',stage='processing',progress=max(float(j.get('progress') or 0),96.0),progress_source='postprocessor',message='Finalizing / merging media…',eta='')
                    elif any(x in line for x in ('Merging formats','Merging','Remuxing','Embedding','Deleting original file','Fixing')):
                        j.update(status='processing',stage='processing',progress=max(float(j.get('progress') or 0),96.0),progress_source='postprocessor',message=line[-320:])
                    if 'ERROR:' in line: j['last_error']=line[-3000:]
                    if j.get('pause_requested'):
                        try: p.terminate()
                        except Exception: pass
                        j.update(status='paused',stage='paused',message='Paused. Resume to continue.',pause_requested=False); p.wait(timeout=10); return
                rc=p.wait()
        except Exception as e:
            j['last_error']=str(e); log_line(j,str(e)); rc=1
        if rc==0:
            f=final if final and final.exists() else None
            if not f:
                # Only inspect this job's final destination candidates; never select another job's file.
                candidates=[x for x in dl.iterdir() if x.is_file() and x.suffix.lower() in MEDIA_EXT and x.stat().st_mtime>=j['created']]
                f=max(candidates,key=lambda x:x.stat().st_mtime) if candidates else None
            if f and f.exists() and f.stat().st_size>0:
                j.update(progress=100.0,status='done',stage='completed',progress_source='verified',message='Download completed and verified',filename=f.name,path=str(f),filesize=f.stat().st_size,final_format=f.suffix.lower().lstrip('.'))
                if idx>1: j['fallback_used']=True
                cleanup_job(work); return
        last_error=j.get('last_error') or 'Requested format is not available.'
        k=classify(last_error)
        if k!='format_unavailable' and idx==1 and 'Requested format' not in last_error and 'requested format' not in last_error.lower():
            # Some post-processing/container failures are still safely recoverable by the next compatibility strategy.
            pass
        j['fallback_reason']=last_error[-1200:]
        if idx < len(attempts):
            j.update(status='fallback',stage='fallback',progress=max(float(j.get('progress') or 0),95.0),message=f'Format unavailable/incompatible. Trying fallback {idx+1}/{len(attempts)}…',progress_source='fallback',fallback_used=True)
            time.sleep(0.25)
            continue
        k=classify(last_error); j.update(status='error',stage='error',error_kind=k,message='Download failed after all compatible fallbacks',error=last_error,help=error_help(k),progress=max(0.0,min(99.0,float(j.get('progress') or 0))))
        cleanup_job(work); return

def newjob(url,d):
    c=cfg();c.update(d.get('settings') or {});jid=uuid.uuid4().hex[:10]
    JOBS[jid]={'id':jid,'url':url,'mode':d.get('mode','video'),'quality':d.get('quality','best'),'container':d.get('container','mp4'),'status':'queued','progress':0,'message':'Queued','created':time.time(),'pause_requested':False,'settings':c,'logs':[]}
    threading.Thread(target=start_job,args=(jid,url,c),daemon=True).start();return jid

@app.route('/')
def index():return render_template('index.html')
@app.route('/api/config',methods=['GET','POST'])
def config():return jsonify(cfg() if request.method=='GET' else save_cfg(request.get_json(silent=True) or {}))
@app.route('/api/health')
def health():
    try:y=run([ytdlp_exe(),'--version'],timeout=10).stdout.strip()
    except Exception:y='unavailable'
    e=engine_status();return jsonify({'ok':True,'yt_dlp':y,'engine':e,'python':sys.version.split()[0],'download_dir':str(downloads_dir()),'appdata':str(APPDATA)})
@app.route('/api/diagnostics/system')
def system_diag():
    e=engine_status(); checks=[]
    checks.append({'name':'Python','ok':True,'detail':sys.version.split()[0]})
    y=run([ytdlp_exe(),'--version'],timeout=10);checks.append({'name':'yt-dlp','ok':y.returncode==0,'detail':(y.stdout or y.stderr).strip()})
    checks.append({'name':'FFmpeg','ok':bool(e['ffmpeg']),'detail':e['ffmpeg'] or 'Not found / cannot start'})
    checks.append({'name':'FFprobe','ok':bool(e['ffprobe']),'detail':e['ffprobe'] or 'Not found / cannot start'})
    d=downloads_dir();checks.append({'name':'Download folder','ok':os.access(d,os.W_OK),'detail':str(d)})
    return jsonify({'ok':all(x['ok'] for x in checks),'checks':checks,'engine':e,'tips':['Use cookie-free mode first.','Re-analyze before retrying a failed quality.','For MP4, use a quality marked MP4-compatible when available.','If FFmpeg fails, run UPDATE.bat, then System Check again.']})
@app.route('/api/repair-engine',methods=['POST'])
def repair_engine():
    try:
        py=BASE/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
        if not py.exists():return jsonify({'ok':False,'error':'Python environment not found. Run START.bat first.'}),400
        p=subprocess.run([str(py),'-m','pip','install','--upgrade','--force-reinstall','imageio-ffmpeg'],cwd=BASE,text=True,capture_output=True,timeout=180,encoding='utf-8',errors='replace')
        e=engine_status();return jsonify({'ok':p.returncode==0 and e['available'],'message':e['message'],'engine':e,'log':(p.stdout+p.stderr)[-6000:]})
    except Exception as ex:return jsonify({'ok':False,'error':str(ex)}),500
@app.route('/api/analyze',methods=['POST'])
def analyze():
    d=request.get_json(silent=True) or {};u=normalize_youtube_url((d.get('url') or '').strip())
    if not u:return jsonify({'ok':False,'error':'Enter a valid supported YouTube URL. Supported forms include youtube.com/watch, /shorts, /live, /embed and youtu.be links.','error_kind':'unsupported_url','help':error_help('unsupported_url')}),400
    c=cfg();c.update(d.get('settings') or {});b=d.get('browser') or browser_from_request()
    if b!='auto':c['browser']=b
    info,err,used=probe(u,c)
    if not info:
        k=classify(err);return jsonify({'ok':False,'error':err,'error_kind':k,'help':error_help(k)}),400
    qs=analyze_formats(info);e=engine_status()
    return jsonify({'ok':True,'id':info.get('id'),'title':info.get('title'),'url':info.get('webpage_url') or u,'thumbnail':info.get('thumbnail'),'duration':info.get('duration'),'duration_string':info.get('duration_string'),'channel':info.get('channel'),'uploader':info.get('uploader'),'description':info.get('description'),'view_count':info.get('view_count'),'like_count':info.get('like_count'),'upload_date':info.get('upload_date'),'qualities':qs,'cookie_browser_used':used,'download_dir':str(downloads_dir()),'engine':e})
@app.route('/api/download',methods=['POST'])
def download():
    d=request.get_json(silent=True) or {};u=normalize_youtube_url((d.get('url') or '').strip())
    if not u:return jsonify({'ok':False,'error':'Invalid or unsupported YouTube URL. Re-analyze the URL before downloading.','error_kind':'unsupported_url','help':error_help('unsupported_url')}),400
    save_cfg(d.get('settings') or {});return jsonify({'ok':True,'job_id':newjob(u,d),'download_dir':str(downloads_dir()),'message':'Download queued with automatic format fallbacks.'})
@app.route('/api/jobs/<jid>')
def status(jid):return jsonify({'ok':True,**JOBS[jid]}) if jid in JOBS else (jsonify({'ok':False}),404)
@app.route('/api/jobs/<jid>/pause',methods=['POST'])
def pause(jid):
    if jid not in JOBS:return jsonify({'ok':False}),404
    JOBS[jid]['pause_requested']=True;return jsonify({'ok':True})
@app.route('/api/jobs/<jid>/resume',methods=['POST'])
def resume(jid):
    if jid not in JOBS:return jsonify({'ok':False}),404
    j=JOBS[jid]
    if j['status']!='paused':return jsonify({'ok':False,'error':'Job is not paused.'}),400
    j['status']='queued';j['progress']=0;j['pause_requested']=False;threading.Thread(target=start_job,args=(jid,j['url'],j['settings']),daemon=True).start();return jsonify({'ok':True})
@app.route('/api/retry/<jid>',methods=['POST'])
def retry(jid):
    if jid not in JOBS:return jsonify({'ok':False}),404
    j=JOBS[jid];return jsonify({'ok':True,'job_id':newjob(j['url'],{'mode':j['mode'],'quality':j['quality'],'container':j['container'],'settings':j['settings']})})
@app.route('/api/files')
def files():
    root=downloads_dir();out=[]
    for p in sorted(root.rglob('*'),key=lambda x:x.stat().st_mtime if x.exists() else 0,reverse=True):
        if p.is_file() and p.suffix.lower() in MEDIA_EXT:out.append({'name':p.name,'relative':p.relative_to(root).as_posix(),'size':p.stat().st_size,'mtime':p.stat().st_mtime,'url':'/download/'+p.relative_to(root).as_posix()})
    return jsonify({'files':out,'download_dir':str(root)})
@app.route('/api/open-download-folder',methods=['POST'])
def open_folder():
    try:
        p=downloads_dir()
        if os.name=='nt':os.startfile(str(p))
        elif sys.platform=='darwin':subprocess.Popen(['open',str(p)])
        else:subprocess.Popen(['xdg-open',str(p)])
        return jsonify({'ok':True,'path':str(p)})
    except Exception as e:return jsonify({'ok':False,'error':str(e)}),500
@app.route('/api/clear-history',methods=['POST'])
def clear_history():
    JOBS.clear()
    for p in LOG_ROOT.glob('*.log'):
        try:p.unlink()
        except Exception:pass
    return jsonify({'ok':True})
@app.route('/api/diagnostics/<jid>')
def diagnostics(jid):
    if jid not in JOBS:return jsonify({'ok':False}),404
    j=JOBS[jid];return jsonify({'ok':True,'id':jid,'status':j['status'],'error':j.get('error'),'error_kind':j.get('error_kind'),'help':j.get('help'),'logs':j.get('logs',[])})
@app.route('/api/test',methods=['POST'])
def test():
    c=cfg();c.update((request.get_json(silent=True) or {}).get('settings') or {});c['use_cookies']=False;c['browser']='none';info,err,_=probe('https://www.youtube.com/watch?v=BaW_jenozKc',c)
    if info:return jsonify({'ok':True,'message':'Cookie-free YouTube connection is working.'})
    k=classify(err);return jsonify({'ok':False,'error':err,'error_kind':k,'help':error_help(k)}),400
@app.route('/api/open-youtube',methods=['POST'])
def open_yt():
    u=(request.get_json(silent=True) or {}).get('url') or 'https://www.youtube.com';webbrowser.open(u);return jsonify({'ok':True})
@app.route('/download/<path:name>')
def dl(name):return send_from_directory(downloads_dir(),name,as_attachment=True)

if __name__=='__main__':
    print(f'Dhurta Media Lite v8 — http://127.0.0.1:5000 — {downloads_dir()}')
    app.run(host='127.0.0.1',port=5000,threaded=True)
