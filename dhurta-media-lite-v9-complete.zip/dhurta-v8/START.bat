@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1 || (echo Python 3.10+ is required. Install Python, then run this file again.&pause&exit /b 1)
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade -r requirements.txt
start "" http://127.0.0.1:5000/
.venv\Scripts\python.exe app.py
pause
